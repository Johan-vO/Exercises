using System;
using System.Collections.Generic;

namespace NordeaProgrammingTask
{
    public class Text
    {
        public List<Sentence> Sentences = new List<Sentence>();

    }
}
