using System;
using System.Collections.Generic;

namespace NordeaProgrammingTask
{
    public class Sentence
    {
        public List<string> Words = new List<string>();

    }
}
