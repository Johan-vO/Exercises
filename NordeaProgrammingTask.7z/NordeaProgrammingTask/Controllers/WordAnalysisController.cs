﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Localization.Internal;
using Microsoft.Extensions.Logging;

namespace NordeaProgrammingTask.Controllers
{
    [ApiController]

    [Route("[controller]/AnalyzeText/{exportType?}")]
    public class WordAnalysisController : ControllerBase
    {
        private readonly ILogger<WordAnalysisController> _logger;

        public WordAnalysisController(ILogger<WordAnalysisController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult AnalyzeText([FromBody()] string textToParse, string exportType)
        {
            //Validations
            //Ensure that the text to parse is not and empty string or null.
            if (string.IsNullOrEmpty(textToParse))
            {
                return BadRequest(new { message = "There was no text to parse on the body." });
            }

            try
            {
                //Split received text into sentences. A sentence is indicated by a period, exclamation mark of question mark.
                //TODO: What about the ellipses? (...)

                char[] punctuationIndicatingEndOfSentence = new char[] { '.', '!', '?' };
                char[] otherPunctuationAndSpace = new char[] { '\"', ',', ';', ':', '/', '\\', '\r', '\n', ' ' };

                //TODO: Consider if there are more characters we wan't to strip out. Or allow only alphabetical characters A-Z?
                //TODO: Adjustments to handle a sentence like: "This is mine!", I shouted when I made the second sentence.
                //TODO: Should words that are repeated in a sentence be listed only once? E.g. "I shouted when I made a  second sentence, I would like to add" will list 'I' 3 times.

                Text parsedText = new Text();
                Sentence sentenceToAdd = null;
                string[] splitWords = null;
                string[] splitSentences = textToParse.Split(punctuationIndicatingEndOfSentence, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < splitSentences.Length; i++)
                {
                    //Split each sentence into words. Strip out punctuation in each sentence, so only words remain.
                    splitWords = splitSentences[i].Split(otherPunctuationAndSpace, StringSplitOptions.RemoveEmptyEntries);

                    //If there was only punctuation marks in the text, we may now sit with no text to parse. Ignore this kind of 'sentence'.
                    if (splitWords.Length == 0)
                        continue;

                    sentenceToAdd = new Sentence();
                    sentenceToAdd.Words.AddRange(splitWords);

                    //Sort the words for each sentence and add this sentence to our parsed text object.
                    sentenceToAdd.Words.Sort();
                    parsedText.Sentences.Add(sentenceToAdd);
                }

                //Sanity check. After the parsing, are there any sentences and words left?
                if (parsedText.Sentences.Count == 0)
                {
                    return BadRequest(new { message = "There were no sentences or words after parsing the text received." });
                }

                //Generate the export based on selected type.
                //Default to XML if no type was provided, or the type does not match: 'XML' or 'CSV'
                if (exportType != null && exportType.ToUpper() == "CSV")
                    return ParseAndGenerateCSV(parsedText);
                else
                    return ParseAndGenerateXML(parsedText);

                //throw new Exception("Testing exception handling and logging.");

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, null, null);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        private FileResult ParseAndGenerateXML(Text parsedText)
        {
            XmlWriterSettings settings = new XmlWriterSettings() { NewLineChars = "\r\n", Indent = true, NewLineOnAttributes = true };
            using (MemoryStream memStream = new MemoryStream())
            {
                using (XmlWriter writer = XmlWriter.Create(memStream, settings))
                {
                    writer.WriteProcessingInstruction("xml", "version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"");
                    writer.WriteStartElement("text");

                    //Loop through the parsedText and create the corresponding XML elements
                    foreach (Sentence sentence in parsedText.Sentences)
                    {
                        writer.WriteStartElement("sentence");

                        foreach (string word in sentence.Words)
                        {
                            writer.WriteStartElement("word");
                            writer.WriteString(word);
                            writer.WriteEndElement(); //End 'word' element.
                        }

                        writer.WriteEndElement(); //End 'sentence' element.
                    }

                    writer.WriteEndElement(); //End 'text' element.
                    writer.WriteEndDocument();
                }

                return File(memStream.ToArray(), "text/xml", "TextExport");
            }
        }

        private FileResult ParseAndGenerateCSV(Text parsedText)
        {
            //Validations: The text may not contain the seperator character, unless it is placed within quotation marks.
            //In this case, not applicable as all punctuation has been stripped out.

            StringBuilder builder = new StringBuilder();
            string seperator = ", ";

            //TODO: Enquire why this specific column layout is required for the CSV export. Although the code is currently according to spec,
            //the columns and rows are misaligned and will create problems if this data should ever be imported.
            //Adding a first column 'sentence number' in the header would be a more accurate reflection of the data. 

            //Columns should be Word 1, Word 2, Word 3 etc. The number of columns will therefore be dependent on the longest sentence.
            int numberOfColumns = 0;
            foreach (Sentence sentence in parsedText.Sentences)
            {
                if (sentence.Words.Count > numberOfColumns)
                    numberOfColumns = sentence.Words.Count;
            }

            //Add one extra column for the first column, which will contain the sentence number.
            //numberOfColumns++;

            //Columns line for CSV
            for (int i = 0; i < numberOfColumns; i++)
            {
                builder.Append("Word " + (i + 1));

                if (i + 1 < numberOfColumns)
                    builder.Append(seperator);
                else
                    builder.AppendLine();
            }

            //Rows for CSV
            for (int i = 0; i < parsedText.Sentences.Count; i++)
            {
                builder.Append("Sentence " + (i + 1) + seperator);
               
                for (int j = 0; j < parsedText.Sentences[i].Words.Count; j++)
                {
                    builder.Append(parsedText.Sentences[i].Words[j]);

                    if (j + 1 < parsedText.Sentences[i].Words.Count)
                        builder.Append(seperator);
                    else
                        builder.AppendLine();
                }
            }

            //Windows european encoding. Allows Excel correct interpretation of CSV files
            //TODO: What will/should the server default encoding be? For now use default encoding.
            //byte[] result = System.Text.Encoding.GetEncoding(1252).GetBytes(builder.ToString());
            byte[] result = System.Text.Encoding.Default.GetBytes(builder.ToString());
            return File(result, "text/csv", "TextExport");
        }
    }

}
