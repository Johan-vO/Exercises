import React, { Component } from 'react';
import { Button } from 'reactstrap';

export class Home extends Component {
    static displayName = Home.name;

    constructor(props) {
        super(props);
        this.state = { textToParse: null, isExporting: false };
    }

    handleChange(e) {
        this.setState({ textToParse: e.target.value })
    }

    handleClick(e) {

        //Check for data before posting
        if (this.state.textToParse == null || this.state.textToParse.length <= 0)
            return;

        this.setState({ errors: null, isExporting: true });

        this.downloadExport(e.target.name == "btnExportCSV" ? "CSV" : "XML");
    }


    async downloadExport(exportType) {
        try
        {
            const response = await fetch("WordAnalysis/AnalyzeText/" + exportType,
                {
                    method: "Post",
                    headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.state.textToParse)
                }
            );

            const downloadData = await response.blob();

            //Create temporary anchor and click it to save file.
            const url = window.URL.createObjectURL(downloadData);
            const link = document.createElement('a');
            link.href = url;
            link.download = "TextExport." + exportType;
         
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        }
        catch(Error)
        {
            this.setState({ errors: Error });
        }

        this.setState({ isExporting: false });
    }

    render() {

        const errors = this.state.errors;

        //Set feedback message
        const haveTextToConvert = this.state.textToParse != null && this.state.textToParse.length > 0;
        var feedbackText = "Awaiting input..";
        if (haveTextToConvert)
            feedbackText = "Input received - READY to analyze and export.";
        if (this.state.isExporting)
            feedbackText = "Converting text..";

        return (
            [<div>
                <h1>Word use analyzer</h1>
                <p>Please enter text to be analyzed:</p>
                <textarea className="form-control" rows="5" name="txtInput" onChange={this.handleChange.bind(this)} />
                <p ><strong>{feedbackText}</strong></p>
                <Button className="btn btn-primary" name="btnExportCSV" onClick={this.handleClick.bind(this)} disabled={!haveTextToConvert || this.state.isExporting} >Export to CSV</Button>
                <Button className="btn btn-primary" name="btnExportXML" onClick={this.handleClick.bind(this)} disabled={!haveTextToConvert || this.state.isExporting} style={{ marginLeft: 10 + "px" }} >Export to XML</Button><br /><br />
            </div>,

            (errors) ? (<div className="form-group"><div className="alert alert-danger"><strong>Error!</strong> {errors.message || 'Something went wrong.'}</div></div>) : null
            ]
        );
    }
}
